// 正式資料確認後，替換此物件；保留 schemaVersion 與各欄位。
window.TEMPLE_LOTS = {
  "schemaVersion": 1,
  "source": "介面展示範例，非本宮典籍",
  "lots": [
    {
      "number": 38,
      "rank": "上中（範例）",
      "title": "第 38 籤版型展示",
      "poem": [
        "【範例佔位・非正式籤詩】",
        "此處放入經確認的第一句籤詩。",
        "此處放入經確認的第二句籤詩。",
        "此處放入經確認的第三句籤詩。",
        "此處放入經確認的第四句籤詩。"
      ],
      "explanation": "【範例佔位】此處顯示使用者提供的完整白話解釋；目前沒有正式解籤內容。",
      "isExample": true
    },
    {
      "number": 1,
      "rank": "未提供",
      "title": "第 1 籤資料展示",
      "poem": [
        "【範例佔位・非正式籤詩】",
        "完整籤詩待提供。"
      ],
      "explanation": "白話解釋待提供。此筆僅供測試多筆抽籤資料。",
      "isExample": true
    }
  ]
};
